@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo 正在处理文件夹: %cd%
echo.

set "count=0"
set "skip_count=0"
set "error_count=0"

REM 获取当前文件夹名（仅文件夹名称，不包含路径）
for %%d in (.) do set "folder_name=%%~nxd"

echo 当前文件夹名: !folder_name!
echo.

echo 正在处理文件...

REM 使用dir命令获取所有文件，避免for循环的变量问题
for /f "delims=" %%f in ('dir /b /a-d 2^>nul') do (
    set "original_file=%%f"
    set "filename=%%~nf"
    set "extension=%%~xf"
    
    REM 排除脚本文件自身
    if /i not "%%f"=="%~nx0" (
        REM 在循环内使用变量延迟展开
        set "new_name=!folder_name!_!filename!!extension!"
        
        echo 检查: "!original_file!" -> "!new_name!"
        
        REM 检查是否是同名文件
        if /i "!original_file!" equ "!new_name!" (
            echo 跳过: "!original_file!" (已经是指定格式)
            set /a skip_count+=1
        ) else (
            REM 检查新文件名是否已存在
            if not exist "!new_name!" (
                echo 正在重命名: "!original_file!" -> "!new_name!"
                ren "!original_file!" "!new_name!"
                
                if errorlevel 1 (
                    echo 错误: 重命名失败
                    set /a error_count+=1
                ) else (
                    echo 成功重命名
                    set /a count+=1
                )
            ) else (
                echo 跳过: "!original_file!" (目标文件已存在)
                set /a skip_count+=1
            )
        )
        echo.
    )
)

echo.
echo ======================
echo 处理完成!
echo ======================
echo 成功重命名: %count% 个文件
echo 跳过: %skip_count% 个文件
echo 错误: %error_count% 个文件
echo.
pause